# AURA-G Sample Pack

Synthetic, deterministic WAV references generated for AURA-G development, demos, regression tests, transcription/MIDI experiments, and model prototyping.

## Layout

- `samples/clean/`
- `samples/crunch/`
- `samples/lead/`
- `samples/acoustic/`
- `samples/lofi_ambient/`
- `samples/physical_model/`
- `samples/transcription_midi/`

All WAVs are mono, 48 kHz, 16-bit PCM. These are **synthetic guitar-like reference signals**, not recordings of a commercial guitar performance.

The pack is intended as a development/test asset set. For production model training, replace or supplement these references with appropriately licensed real recordings.

See `manifest.json` for per-file metadata.
